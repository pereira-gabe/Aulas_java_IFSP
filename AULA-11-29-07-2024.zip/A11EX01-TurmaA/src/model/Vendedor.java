/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ALUNO
 */
public class Vendedor extends Pessoa {
    private int idVendedor;
    private String login;
    private String senha;
    private String foto;
    private Date ultimoLogin;

    public Vendedor() {
    }

    public Vendedor(int idVendedor, String login, String senha, String foto, Date ultimoLogin) {
        this.idVendedor = idVendedor;
        this.login = login;
        this.senha = senha;
        this.foto = foto;
        this.ultimoLogin = ultimoLogin;
    }

    public Vendedor(int idVendedor, String login, String senha, String foto, Date ultimoLogin, int id, String nome, String cpf) {
        super(id, nome, cpf);
        this.idVendedor = idVendedor;
        this.login = login;
        this.senha = senha;
        this.foto = foto;
        this.ultimoLogin = ultimoLogin;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Date getUltimoLogin() {
        return ultimoLogin;
    }

    public void setUltimoLogin(Date ultimoLogin) {
        this.ultimoLogin = ultimoLogin;
    }
}

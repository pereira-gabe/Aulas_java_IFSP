/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;
import java.util.List;

/**
 *
 * @author ALUNO
 */
public class Venda {
    private int id;
    private Date data;
    private Vendedor vendedor;
    private Pessoa cliente;
    private List<ItensVenda> produtos;

    public Venda() {
    }

    public Venda(int id, Date data, Vendedor vendedor, Pessoa cliente, List<ItensVenda> produtos) {
        this.id = id;
        this.data = data;
        this.vendedor = vendedor;
        this.cliente = cliente;
        this.produtos = produtos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public Pessoa getCliente() {
        return cliente;
    }

    public void setCliente(Pessoa cliente) {
        this.cliente = cliente;
    }

    public List<ItensVenda> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<ItensVenda> produtos) {
        this.produtos = produtos;
    }
}

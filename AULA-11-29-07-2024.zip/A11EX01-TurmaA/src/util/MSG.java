/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import javax.swing.JOptionPane;

/**
 *
 * @author conta
 */
public class MSG {
    private static String titulo = "Meu Sistema";
    
    public static String input(String texto){
        return JOptionPane.showInputDialog(null, texto, titulo, JOptionPane.QUESTION_MESSAGE);
    }
    
    public static void info(String texto){
        JOptionPane.showMessageDialog(null, texto, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void erro(String texto){
        JOptionPane.showMessageDialog(null, texto, titulo, JOptionPane.ERROR_MESSAGE);
    }
    
    public static int yesno(String texto){
        return JOptionPane.showConfirmDialog(null, texto);
    }
}

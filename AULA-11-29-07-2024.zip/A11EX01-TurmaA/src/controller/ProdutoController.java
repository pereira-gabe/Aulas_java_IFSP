/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.ProdutoDAO;
import java.util.List;
import model.Produto;

/**
 *
 * @author ALUNO
 */
public abstract class ProdutoController {
    public static boolean cadastrar(Produto p){
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.inserir(p);
    }
    
    public static boolean excluir(Produto p){
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.excluir(p);
    }
    
    public static boolean alterar(Produto p){
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.alterar(p);
    }
    
    public static List<Produto> buscar(String busca){
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.buscar(busca);
    }
    
    public static Produto buscar(int id){
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.buscar(id);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.VendedorDAO;
import java.util.List;
import model.Vendedor;

/**
 *
 * @author ALUNO
 */
public abstract class VendedorController {
    public static boolean cadastrar(Vendedor v){
        VendedorDAO vendedorDAO = new VendedorDAO();
        return vendedorDAO.inserir(v);
    }
    
    public static boolean excluir(Vendedor v){
        VendedorDAO vendedorDAO = new VendedorDAO();
        return vendedorDAO.excluir(v);
    }
    
    public static boolean alterar(Vendedor v){
        VendedorDAO vendedorDAO = new VendedorDAO();
        return vendedorDAO.alterar(v);
    }
    
    public static List<Vendedor> buscar(String busca){
        VendedorDAO vendedorDAO = new VendedorDAO();
        return vendedorDAO.buscar(busca);
    }
    
    public static Vendedor buscar(int id){
        VendedorDAO vendedorDAO = new VendedorDAO();
        return vendedorDAO.buscar(id);
    } 
}

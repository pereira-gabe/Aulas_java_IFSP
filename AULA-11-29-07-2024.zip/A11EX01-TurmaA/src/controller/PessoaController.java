/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.PessoaDAO;
import java.util.List;
import model.Pessoa;

/**
 *
 * @author conta
 */
public abstract class PessoaController {
    public static boolean cadastrar(Pessoa p){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.inserir(p);
    }
    
    public static boolean excluir(Pessoa p){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.excluir(p);
    }
    
    public static boolean alterar(Pessoa p){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.alterar(p);
    }
    
    public static List<Pessoa> buscar(String busca){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.buscar(busca);
    }
    
    public static List<Pessoa> buscar(int id, String cpf){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.buscar(id, cpf);
    }
    
    public static Pessoa buscar(int id){
        PessoaDAO pessoaDAO = new PessoaDAO();
        return pessoaDAO.buscar(id);
    }
}

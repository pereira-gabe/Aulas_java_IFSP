/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.VendaDAO;
import java.util.List;
import model.ItensVenda;
import model.Venda;

/**
 *
 * @author ALUNO
 */
public class VendaController {
    public static boolean cadastrar(Venda v){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.inserir(v);
    }
    
    public static boolean excluir(Venda v){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.excluir(v);
    }
    
    public static boolean alterar(Venda v){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.alterar(v);
    }
    
    public static List<Venda> buscar(){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.buscar();
    }
    
    public static Venda buscar(int id){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.buscar(id);
    }
    
    /*public static boolean cadastrarItemVenda(ItensVenda itemVenda){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.inserirItemVenda(itemVenda);
    }*/
    
    public static boolean excluirItemVenda(ItensVenda itemVenda){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.excluirItemVenda(itemVenda);
    }
    
    public static boolean alterarItemVenda(ItensVenda itemVenda){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.alterarItemVenda(itemVenda);
    }
    
    public static List<ItensVenda> buscarItensVendas(int idVenda){
        VendaDAO vendaDAO = new VendaDAO();
        return vendaDAO.buscarItensVenda(idVenda);
    }
}

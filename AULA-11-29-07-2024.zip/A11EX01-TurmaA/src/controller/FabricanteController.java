/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.FabricanteDAO;
import java.util.List;
import model.Fabricante;

/**
 *
 * @author ALUNO
 */
public class FabricanteController {
    public static boolean cadastrar(Fabricante f){
        FabricanteDAO fabricanteDAO = new FabricanteDAO();
        return fabricanteDAO.inserir(f);
    }
    
    public static boolean excluir(Fabricante f){
        FabricanteDAO fabricanteDAO = new FabricanteDAO();
        return fabricanteDAO.excluir(f);
    }
    
    public static boolean alterar(Fabricante f){
        FabricanteDAO fabricanteDAO = new FabricanteDAO();
        return fabricanteDAO.alterar(f);
    }
    
    public static List<Fabricante> buscar(String busca){
        FabricanteDAO fabricanteDAO = new FabricanteDAO();
        return fabricanteDAO.buscar(busca);
    }
    
    public static Fabricante buscar(int id){
        FabricanteDAO fabricanteDAO = new FabricanteDAO();
        return fabricanteDAO.buscar(id);
    }
}

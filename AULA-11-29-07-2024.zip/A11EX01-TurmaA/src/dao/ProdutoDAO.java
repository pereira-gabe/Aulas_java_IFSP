/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.FabricanteController;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Fabricante;
import model.Produto;

/**
 *
 * @author ALUNO
 */
public class ProdutoDAO extends Conexao {
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public boolean inserir(Produto p){
        try {
            query = "INSERT INTO Produto VALUES (0,?,?,?,?,?,?)";
            ps = con.prepareStatement(query);
            ps.setInt(1, p.getFabricante().getId());
            ps.setString(2, p.getNome());
            ps.setString(3, p.getModelo());
            ps.setString(4, p.getCor());
            ps.setDouble(5, p.getPeso());
            ps.setDouble(6, p.getValor());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Produto p){
        try {
            query = "DELETE FROM Produto WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, p.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Produto p){
         try {
            query = "UPDATE Produto SET idFabricante = ?, nome = ?, modelo = ?, cor = ?, peso = ?, valor = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, p.getFabricante().getId());
            ps.setString(2, p.getNome());
            ps.setString(3, p.getModelo());
            ps.setString(4, p.getCor());
            ps.setDouble(5, p.getPeso());
            ps.setDouble(6, p.getValor());
            ps.setInt(7, p.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Produto> buscar(String busca){
        List<Produto> lista = new ArrayList<Produto>();
        
        try {
            query = "SELECT * FROM Produto WHERE nome LIKE CONCAT('%', ?, '%') OR modelo LIKE CONCAT('%', ?, '%') OR cor LIKE CONCAT('%', ?, '%') OR peso LIKE CONCAT('%', ?, '%') OR valor LIKE CONCAT('%', ?, '%')ORDER BY nome";
            ps = con.prepareStatement(query);
            ps.setString(1, busca);
            ps.setString(2, busca);
            ps.setString(3, busca);
            ps.setString(4, busca);
            ps.setString(5, busca);
            rs = ps.executeQuery();
            
            Fabricante fabricante;
            
            while(rs.next()){
                fabricante = FabricanteController.buscar(rs.getInt("idFabricante"));
                lista.add(
                    new Produto(
                        rs.getInt("id"),
                        fabricante,
                        rs.getString("nome"),
                        rs.getString("modelo"),
                        rs.getString("cor"),
                        rs.getDouble("peso"),
                        rs.getDouble("valor")                        
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public Produto buscar(int id){
        Produto produto;
        produto = null;
        
        try {
            query = "SELECT * FROM Produto WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            Fabricante fabricante;
            
            while(rs.next()){
                fabricante = FabricanteController.buscar(rs.getInt("idFabricante"));
                produto = new Produto(
                    rs.getInt("id"),
                    fabricante,
                    rs.getString("nome"),
                    rs.getString("modelo"),
                    rs.getString("cor"),
                    rs.getDouble("peso"),
                    rs.getDouble("valor")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return produto;
    }
}

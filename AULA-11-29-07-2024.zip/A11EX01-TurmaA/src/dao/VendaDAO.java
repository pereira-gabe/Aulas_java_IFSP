/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.PessoaController;
import controller.ProdutoController;
import controller.VendaController;
import controller.VendedorController;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import model.ItensVenda;
import model.Pessoa;
import model.Produto;
import model.Venda;
import model.Vendedor;

/**
 *
 * @author ALUNO
 */
public class VendaDAO extends Conexao {
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public boolean inserir(Venda v){
        try {
            query = "INSERT INTO Venda VALUES (0,?,?,?)";
            ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS); 
            ps.setString(1, df.format(v.getData()));
            ps.setInt(2, v.getVendedor().getIdVendedor());
            ps.setInt(3, v.getCliente().getId());
            
            if(ps.executeUpdate() > 0){
                rs = ps.getGeneratedKeys();
                if(rs.next()){ 
                    int idVenda = rs.getInt(1); 

                    for(ItensVenda registro : v.getProdutos()){
                        this.inserirItemVenda(new ItensVenda(
                                0, 
                                idVenda, 
                                registro.getProduto(), 
                                registro.getQuantidade(), 
                                registro.getValor()
                            )
                        );
                    }
                } 
                
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    private boolean inserirItemVenda(ItensVenda itemVenda){
        try {
            query = "INSERT INTO ItensVenda VALUES (0,?,?,?,?)";
            ps = con.prepareStatement(query);
            ps.setInt(1, itemVenda.getIdVenda());
            ps.setInt(2, itemVenda.getProduto().getId());
            ps.setInt(3, itemVenda.getQuantidade());
            ps.setFloat(4, itemVenda.getValor());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Venda v){
        try {
            query = "DELETE FROM Venda WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, v.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
     public boolean excluirItemVenda(ItensVenda itemVenda){
        try {
            query = "DELETE FROM ItensVenda WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, itemVenda.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    
    public boolean alterar(Venda v){
         try {
            query = "UPDATE Venda SET data = ?, idVendedor = ?, idCliente = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, df.format(v.getData()));
            ps.setInt(2, v.getVendedor().getIdVendedor());
            ps.setInt(3, v.getCliente().getId());
            ps.setInt(4, v.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterarItemVenda(ItensVenda itemVenda){
         try {
            query = "UPDATE ItensVenda SET idVenda = ?, idProduto = ?, quantidade = ?, valor = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, itemVenda.getIdVenda());
            ps.setInt(2, itemVenda.getProduto().getId());
            ps.setInt(3, itemVenda.getQuantidade());
            ps.setFloat(4, itemVenda.getValor());
            ps.setInt(5, itemVenda.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public Venda buscar(int id){
        Venda venda;
        venda = null;
        
        try {
            query = "SELECT * FROM Venda WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            Vendedor vendedor;
            Pessoa cliente;
            List<ItensVenda> produtos;
            
            while(rs.next()){
               vendedor = VendedorController.buscar(rs.getInt("idVendedor"));
               cliente = PessoaController.buscar(rs.getInt("idCliente"));
               produtos = this.buscarItensVenda(id);
               venda = new Venda(
                    rs.getInt("id"),
                    df.parse(rs.getString("data")),
                    vendedor,
                    cliente,
                    produtos
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return venda;
    }
    
    public List<Venda> buscar(){
        List<Venda> lista = new ArrayList<Venda>();
        
        try {
            query = "SELECT * FROM Venda ORDER BY data";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            
            while(rs.next()){
               Vendedor vendedor = VendedorController.buscar(rs.getInt("idVendedor"));
               Pessoa cliente = PessoaController.buscar(rs.getInt("idCliente"));
               List<ItensVenda> produtos = this.buscarItensVenda(rs.getInt("id"));
               lista.add(
                    new Venda(
                        rs.getInt("id"),
                        df.parse(rs.getString("data")),
                        vendedor,
                        cliente,
                        produtos
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public List<ItensVenda> buscarItensVenda(int idVenda){
        List<ItensVenda> lista = new ArrayList<ItensVenda>();
        
        try {
            query = "SELECT * FROM ItensVenda WHERE idVenda = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, idVenda);
            rs = ps.executeQuery();
            
            Venda venda;
            Produto produto;
            
            while(rs.next()){
                produto = ProdutoController.buscar(rs.getInt("idProduto"));
                lista.add(
                    new ItensVenda(
                        rs.getInt("id"),
                        rs.getInt("idVenda"),
                        produto,
                        rs.getInt("quantidade"),
                        rs.getFloat("valor")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
}

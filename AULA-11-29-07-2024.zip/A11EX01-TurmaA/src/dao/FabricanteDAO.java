/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Fabricante;

/**
 *
 * @author ALUNO
 */
public class FabricanteDAO extends Conexao {
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public boolean inserir(Fabricante f){
        try {
            query = "INSERT INTO Fabricante VALUES (0,?)";
            ps = con.prepareStatement(query);
            ps.setString(1, f.getNome());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Fabricante f){
        try {
            query = "DELETE FROM Fabricante WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, f.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Fabricante f){
         try {
            query = "UPDATE Fabricante SET nome = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, f.getNome());
            ps.setInt(2, f.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Fabricante> buscar(String busca){
        List<Fabricante> lista = new ArrayList<Fabricante>();
        
        try {
            query = "SELECT * FROM Fabricante WHERE nome LIKE CONCAT('%', ?, '%') ORDER BY nome";
            ps = con.prepareStatement(query);
            ps.setString(1, busca);
            rs = ps.executeQuery();
            
            while(rs.next()){
                lista.add(
                    new Fabricante(
                        rs.getInt("id"),
                        rs.getString("nome")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public Fabricante buscar(int id){
        Fabricante fabricante;
        fabricante = null;
        
        try {
            query = "SELECT * FROM Fabricante WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            while(rs.next()){
                fabricante = new Fabricante(
                    rs.getInt("id"),
                    rs.getString("nome")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return fabricante;
    }
}

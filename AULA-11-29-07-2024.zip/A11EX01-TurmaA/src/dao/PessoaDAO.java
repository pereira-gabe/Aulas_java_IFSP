/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Pessoa;

import java.sql.*;

/**
 *
 * @author conta
 */
public class PessoaDAO extends Conexao {
    
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public boolean inserir(Pessoa p){
        try {
            query = "INSERT INTO Pessoas VALUES (0,?,?)";
            ps = con.prepareStatement(query);
            ps.setString(1, p.getNome());
            ps.setString(2, p.getCpf());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Pessoa p){
        try {
            query = "DELETE FROM Pessoas WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, p.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Pessoa p){
         try {
            query = "UPDATE Pessoas SET nome = ?, cpf = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, p.getNome());
            ps.setString(2, p.getCpf());
            ps.setInt(3, p.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Pessoa> buscar(String busca){
        List<Pessoa> lista = new ArrayList<Pessoa>();
        
        try {
            query = "SELECT * FROM Pessoas WHERE nome LIKE CONCAT('%', ?, '%') OR cpf LIKE CONCAT('%', ?, '%') ORDER BY nome";
            ps = con.prepareStatement(query);
            ps.setString(1, busca);
            ps.setString(2, busca);
            rs = ps.executeQuery();
            
            while(rs.next()){
                lista.add(
                    new Pessoa(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public List<Pessoa> buscar(int id, String cpf){
        List<Pessoa> lista = new ArrayList<Pessoa>();
        
        try {
            query = "SELECT * FROM Pessoas WHERE cpf LIKE CONCAT('%', ?, '%') AND id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ps.setString(2, cpf);
            rs = ps.executeQuery();
            
            while(rs.next()){
                lista.add(
                    new Pessoa(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public Pessoa buscar(int id){
        Pessoa pessoa;
        pessoa = null;
        
        try {
            query = "SELECT * FROM Pessoas WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            while(rs.next()){
                pessoa = new Pessoa(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return pessoa;
    }
}

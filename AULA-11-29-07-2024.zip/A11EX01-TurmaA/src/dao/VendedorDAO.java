/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.PessoaController;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import model.Pessoa;
import model.Vendedor;

/**
 *
 * @author ALUNO
 */
public class VendedorDAO extends Conexao {
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public boolean inserir(Vendedor v){
        try {
            query = "INSERT INTO Vendedor VALUES (0,?,?,?,?,?)";
            ps = con.prepareStatement(query);
            ps.setInt(1, v.getId());
            ps.setString(2, v.getLogin());
            ps.setString(3, v.getSenha());
            ps.setString(4, v.getFoto());
            ps.setString(5, df.format(v.getUltimoLogin()));
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Vendedor v){
        try {
            query = "DELETE FROM Vendedor WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, v.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Vendedor v){
         try {
            query = "UPDATE Vendedor SET login = ?, senha = ?, foto = ?, ultimoLogin = ? WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, v.getLogin());
            ps.setString(2, v.getSenha());
            ps.setString(3, v.getFoto());
            ps.setString(5, df.format(v.getUltimoLogin()));
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Vendedor> buscar(String busca){
        List<Vendedor> lista = new ArrayList<Vendedor>();
        
        try {
            query = "SELECT * FROM Vendedor WHERE login LIKE CONCAT('%', ?, '%') ORDER BY login";
            ps = con.prepareStatement(query);
            ps.setString(1, busca);
            rs = ps.executeQuery();
            
            Pessoa pessoa;
            
            while(rs.next()){
                pessoa = PessoaController.buscar(rs.getInt("idPessoa"));
                lista.add(
                    new Vendedor(
                        rs.getInt("id"),
                        rs.getString("login"),
                        rs.getString("senha"),
                        rs.getString("foto"),
                        df.parse(rs.getString("ultimoLogin")),
                        pessoa.getId(),
                        pessoa.getNome(),
                        pessoa.getCpf()
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
    
    public Vendedor buscar(int id){
        Vendedor vendedor;
        vendedor = null;
        
        try {
            query = "SELECT * FROM Vendedor WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            Pessoa pessoa;
            
            while(rs.next()){
               pessoa = PessoaController.buscar(rs.getInt("idPessoa"));
               vendedor = new Vendedor(
                    rs.getInt("id"),
                    rs.getString("login"),
                    rs.getString("senha"),
                    rs.getString("foto"),
                    df.parse(rs.getString("ultimoLogin")),
                    pessoa.getId(),
                    pessoa.getNome(),
                    pessoa.getCpf()
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return vendedor;
    }
}

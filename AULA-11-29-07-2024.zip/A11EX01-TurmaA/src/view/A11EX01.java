/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

import controller.FabricanteController;
import controller.PessoaController;
import controller.ProdutoController;
import controller.VendaController;
import controller.VendedorController;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Fabricante;
import model.ItensVenda;
import model.Pessoa;
import model.Produto;
import model.Venda;
import model.Vendedor;
import util.MSG;

/**
 *
 * @author ALUNO
 */
public class A11EX01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*List<Pessoa> pessoas = new ArrayList<Pessoa>();
        Pessoa pessoa1 = new Pessoa();
        pessoas = PessoaController.buscar("");
        
        for(Pessoa registro : pessoas){
            System.out.print("# " + registro.getId());
            System.out.print(" | ");
            System.out.print("Nome " + registro.getNome());
            System.out.print(" | ");
            System.out.print("CPF " + registro.getCpf());
            System.out.println("\n");
        }*/
        
        /*int id = 0;
        String nome = MSG.input("Nome:");
        String cpf = MSG.input("CPF:");
        
        pessoa1 = new Pessoa(id, nome, cpf);
        
        if(PessoaController.cadastrar(pessoa1)){
            MSG.info("Sucesso ao cadastrar!");
        }else{
            MSG.erro("Erro ao cadastrar!");
        }*/
        
        /*int id = Integer.parseInt(MSG.input("Código:"));
        String nome = MSG.input("Nome:");
        String cpf = MSG.input("CPF:");
        
        pessoa1 = new Pessoa(id, nome, cpf);
        
        if(PessoaController.alterar(pessoa1)){
            MSG.info("Sucesso ao alterar!");
        }else{
            MSG.erro("Erro ao alterar!");
        }*/
        
        /*int excluir = MSG.yesno("Deseja realmente excluir?");
        if(excluir == 0){
            int id = Integer.parseInt(MSG.input("Qual o código do registro que deseja excluir?"));
            pessoa1 = new Pessoa(id, null, null);
            if(PessoaController.excluir(pessoa1)){
                MSG.info("Sucesso ao excluir!");
            }else{
                MSG.erro("Erro ao excluir!");
            }
        }*/
        
        /*
        --------------------------------------
        FABRICANTE
        */
        
        /*List<Pessoa> pessoas = new ArrayList<Pessoa>();
        Pessoa pessoa1 = new Pessoa();
        pessoas = PessoaController.buscar("");
        
        for(Pessoa registro : pessoas){
            System.out.print("# " + registro.getId());
            System.out.print(" | ");
            System.out.print("Nome " + registro.getNome());
            System.out.print(" | ");
            System.out.print("CPF " + registro.getCpf());
            System.out.println("\n");
        }*/
        
        /*int id = 0;
        String nome = MSG.input("Nome:");
        Fabricante fabricante1 = new Fabricante(id, nome);
        
        if(FabricanteController.cadastrar(fabricante1)){
            MSG.info("Sucesso ao cadastrar!");
        }else{
            MSG.erro("Erro ao cadastrar!");
        }*/
        
        /*int id = Integer.parseInt(MSG.input("Código:"));
        String nome = MSG.input("Nome:");
        String cpf = MSG.input("CPF:");
        
        pessoa1 = new Pessoa(id, nome, cpf);
        
        if(PessoaController.alterar(pessoa1)){
            MSG.info("Sucesso ao alterar!");
        }else{
            MSG.erro("Erro ao alterar!");
        }*/
        
        /*int excluir = MSG.yesno("Deseja realmente excluir?");
        if(excluir == 0){
            int id = Integer.parseInt(MSG.input("Qual o código do registro que deseja excluir?"));
            pessoa1 = new Pessoa(id, null, null);
            if(PessoaController.excluir(pessoa1)){
                MSG.info("Sucesso ao excluir!");
            }else{
                MSG.erro("Erro ao excluir!");
            }
        }*/
        
        /* VENDEDOR */
        
        /*int id = 0;
        int idPessoa = Integer.parseInt(MSG.input("Qual o código da pessoa?"));
        
        Pessoa pessoa = new Pessoa();
        pessoa = PessoaController.buscar(idPessoa);
        
        String login = MSG.input("Qual o login?");
        String senha = MSG.input("Qual a senha?");
        String foto = MSG.input("Qual o caminho da foto?");
        
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date ultimoLogin = null;
        
        try {
            ultimoLogin = df.parse(df.format(new Date()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        String nomePessoa = pessoa.getNome();
        String cpf = pessoa.getCpf();
        
        Vendedor vendedor1 = new Vendedor(id, login, senha, foto, ultimoLogin, idPessoa, nomePessoa, cpf);
        
        if(VendedorController.cadastrar(vendedor1)){
            MSG.info("Sucesso ao cadastrar!");
        }else{
            MSG.erro("Erro ao cadastrar!");
        }*/
        
        /*SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        List<Vendedor> vendedores = new ArrayList<Vendedor>();
        Vendedor vendedor1 = new Vendedor();
        vendedores = VendedorController.buscar("");
        
        for(Vendedor registro : vendedores){
            System.out.print("# " + registro.getId());
            System.out.print(" | ");
            System.out.print("Nome " + registro.getNome());
            System.out.print(" | ");
            System.out.print("CPF " + registro.getCpf());
            System.out.print(" | ");
            System.out.print("Login " + registro.getLogin());
            System.out.print(" | ");
            System.out.print("Senha " + registro.getSenha());
            System.out.print(" | ");
            System.out.print("Foto " + registro.getFoto());
            System.out.print(" | ");
            System.out.print("UL " + df.format(registro.getUltimoLogin()));
            System.out.println("\n");
        }*/
        
        /*
        --------------------------------------
        PRODUTO
        */
        
        /*List<Produto> produtos = new ArrayList<Produto>();
        Produto produto1 = new Produto();
        produtos = ProdutoController.buscar("");
        
        for(Produto registro : produtos){
            System.out.print("# " + registro.getId());
            System.out.print(" | ");
            System.out.print("Nome " + registro.getNome());
            System.out.print(" | ");
            System.out.print("Fabricante " + registro.getFabricante().getNome());
            System.out.print(" | ");
            System.out.print("Modelo " + registro.getModelo());
            System.out.print(" | ");
            System.out.print("Cor " + registro.getCor());
            System.out.print(" | ");
            System.out.print("Peso " + registro.getPeso());
            System.out.print(" | ");
            System.out.print("Valor " + registro.getValor());
            System.out.println("\n");
        }*/
        
        /*int id = 0;
        int idFabricante = Integer.parseInt(MSG.input("Qual o código do Fabricante?"));
        
        Fabricante fabricante1 = FabricanteController.buscar(idFabricante);
        
        String nome = MSG.input("Nome:");
        String modelo = MSG.input("Modelo:");
        String cor = MSG.input("Cor:");
        double peso = Double.parseDouble(MSG.input("Peso:"));
        double valor = Double.parseDouble(MSG.input("Valor:"));
        
        Produto produto1 = new Produto(id, fabricante1, nome, modelo, cor, peso, valor);
        
        if(ProdutoController.cadastrar(produto1)){
            MSG.info("Sucesso ao cadastrar!");
        }else{
            MSG.erro("Erro ao cadastrar!");
        }*/
        
         /*
        --------------------------------------
        VENDA
        */
        
        int id = 0;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dataVenda = null;
        
        try {
            dataVenda = df.parse(df.format(new Date()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        int idVendedor = Integer.parseInt(MSG.input("Qual o código do Vendedor?"));
        Vendedor vendedor = VendedorController.buscar(idVendedor);
        
        int idCliente = Integer.parseInt(MSG.input("Qual o código do Cliente?"));
        Pessoa pessoa = PessoaController.buscar(idCliente);

        int qtdProdutos = Integer.parseInt(MSG.input("Quantos produtos você deseja?"));
        
        List<ItensVenda> listaProdutos = new ArrayList<ItensVenda>();
        
        for(int i = 0; i < qtdProdutos; i++){
            int idProduto = Integer.parseInt(MSG.input("Qual o código do produto?"));
            Produto produto = ProdutoController.buscar(idProduto);
            
            int quantidade = Integer.parseInt(MSG.input("Quantos itens você deseja desse produto? \n" + produto.getNome()));
            
            double valorProduto = produto.getValor();
            
            double valorTotalProduto = quantidade * valorProduto; 
            
            float valorVenda = Float.parseFloat(MSG.input("Qual o valor da venda? \nValor sugerido R$ " + valorTotalProduto + "(" + quantidade + " x " + valorProduto + ")"));
            
            ItensVenda itensVenda = new ItensVenda(id, 0, produto, quantidade, valorVenda);
        
            listaProdutos.add(itensVenda);
        }
        
        Venda venda1 = new Venda(id, dataVenda, vendedor, pessoa, listaProdutos);
        
        if(VendaController.cadastrar(venda1)){
            MSG.info("Sucesso ao cadastrar!");
        }else{
            MSG.erro("Erro ao cadastrar!");
        }
        
        /*List<Venda> vendas = new ArrayList<Venda>();
        vendas = VendaController.buscar();
        
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        
        for(Venda registro : vendas){
            System.out.print("# " + registro.getId());
            System.out.print(" | ");
            System.out.print("Data " + df.format(registro.getData()));
            System.out.print("\n");
            System.out.print("Vendedor: " + registro.getVendedor().getNome());
            System.out.print("\n");
            System.out.print("Cliente: " + registro.getCliente().getNome());
            System.out.print("\n");
            
            System.out.println("--- PRODUTOS ---");
            
            List<ItensVenda> itensVenda = new ArrayList<ItensVenda>();
            itensVenda = VendaController.buscarItensVendas(registro.getId());
            
            float valorTotalVenda = 0;
            
            for(ItensVenda registroItens : itensVenda){
                System.out.print("# " + registroItens.getId());
                System.out.print("\n");
                System.out.print(registroItens.getProduto().getNome());
                System.out.print(" R$ " + registroItens.getValor());
                System.out.print(" Qtd. " + registroItens.getQuantidade());
                System.out.print("\n");
                
                valorTotalVenda = valorTotalVenda + registroItens.getValor();
            }
            System.out.println("----------------");
            System.out.println("Valor TOTAL: R$ " + valorTotalVenda);
            
            System.out.println("\n");
        }*/
    }
}

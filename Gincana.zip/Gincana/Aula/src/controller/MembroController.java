package controller;

import dao.MembroDAO;
import model.Membro;
import java.util.List;

public class MembroController {

    private static MembroDAO membroDAO = new MembroDAO();

    public static boolean cadastrar(Membro membro) {
        return membroDAO.inserir(membro);
    }

    public static boolean excluir(Membro membro) {
        return membroDAO.excluir(membro);
    }

    public static boolean alterar(Membro membro) {
        return membroDAO.alterar(membro);
    }

    public static List<Membro> buscar(int id) {
        return membroDAO.buscar(id);
    }
}

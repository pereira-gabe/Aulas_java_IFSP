/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.EquipeDAO;
import java.util.List;
import model.Equipe;

/**
 *
 * @author ALUNO
 */
public class EquipeController {
    public static boolean cadastrar(Equipe e){
        EquipeDAO EquipeDAO = new EquipeDAO();
        return EquipeDAO.inserir(e);
    }
    
    public static boolean excluir(Equipe e){
        EquipeDAO EquipeDAO = new EquipeDAO();
        return EquipeDAO.excluir(e);
    }
    
    public static boolean alterar(Equipe e){
        EquipeDAO EquipeDAO = new EquipeDAO();
        return EquipeDAO.alterar(e);
    }
    
    public static List<Equipe> buscar(int codigo){
        EquipeDAO EquipeDAO = new EquipeDAO();
        return EquipeDAO.buscar(codigo);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;

/**
 *
 * @author ALUNO
 */
public class Conexao {
    protected Connection con;
    protected Statement st;
    protected String query;

    public Conexao() {
        try {
            final String URL = "jdbc:mysql://localhost/bdgincana";
            final String DRIVER = "com.mysql.cj.jdbc.Driver";
            final String USUARIO = "root";
            final String SENHA = "";
            Class.forName(DRIVER);
            con = DriverManager.getConnection(URL, USUARIO, SENHA);
            st = con.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
}

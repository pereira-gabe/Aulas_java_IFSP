/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Equipe;

import java.sql.*;

/**
 *
 * @author conta
 */
public class EquipeDAO extends Conexao {
    
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public boolean inserir(Equipe eq){
        try {
            query = "INSERT INTO `tbequipes` (`id`, `nome`, `descricao`) VALUES (NULL, ?, ?)";
            ps = con.prepareStatement(query);
            ps.setString(1, eq.getNome());
            ps.setString(2, eq.getDescricao());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Equipe eq){
        try {
            query = "DELETE FROM tbequipes WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, eq.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Equipe eq){
         try {
            query = "UPDATE tbequipes SET nome = ?, `descricao` = ? WHERE `tbequipes`.`id` = ?;";
            ps = con.prepareStatement(query);
            ps.setString(1, eq.getNome());
            ps.setString(2, eq.getDescricao());
            ps.setInt(3, eq.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Equipe> buscar(int codigo){
        List<Equipe> lista = new ArrayList<Equipe>();
        
        try {
            query = "SELECT * FROM tbequipes WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, codigo);
            rs = ps.executeQuery();
            
            while(rs.next()){
                lista.add(
                    new Equipe(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Membro;

import java.sql.*;

/**
 *
 * @author conta
 */
public class MembroDAO extends Conexao {
    
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public boolean inserir(Membro m){
        try {
            query = "INSERT INTO tbmembros_equipe (`id`, `nome`, `idade`, `funcao`, `codEquipe`) VALUES (NULL, ?, ?, ?, ?)";
            ps = con.prepareStatement(query);
            ps.setString(1, m.getNome());
            ps.setInt(2, m.getIdade());
            ps.setString(3, m.getFuncao());
            ps.setInt(4, m.getCodEquipe());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    public boolean excluir(Membro m){
        try {
            query = "DELETE FROM tbmembros_equipe WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, m.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public boolean alterar(Membro m){
         try {
            query = "UPDATE `tbmembros_equipe` SET `nome` = ?, `idade` = ?, `funcao` = ?, `codEquipe` = ? WHERE `tbmembros_equipe`.`id` = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, m.getNome());
            ps.setInt(2, m.getIdade());
            ps.setString(3, m.getFuncao());
            ps.setInt(4, m.getCodEquipe());
            ps.setInt(5, m.getId());
            
            if(ps.executeUpdate() > 0){
                return true;
            }
        } catch (Exception e) {
               e.printStackTrace();
        }
        return false;
    }
    
    public List<Membro> buscar(int codigo){
        List<Membro> lista = new ArrayList<Membro>();
        
        try {
            query = "SELECT * FROM tbmembros_equipe WHERE id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, codigo);
            rs = ps.executeQuery();
            
            while(rs.next()){
                lista.add(
                    new Membro(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getInt("idade"),
                        rs.getString("funcao"),
                        rs.getInt("codEquipe")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            lista = null;
        }
        
        return lista;
    }
}

package View;

import controller.EquipeController;
import controller.MembroController;
import model.Equipe;
import model.Membro;
import javax.swing.*;
import java.util.List;

public class View {
    public static void main(String[] args) {
        while (true) {
            String menu = "Escolha uma opção:\n"
                        + "1. Adicionar Equipe\n"
                        + "2. Alterar Equipe\n"
                        + "3. Excluir Equipe\n"
                        + "4. Buscar Equipe\n"
                        + "5. Adicionar Membro\n"
                        + "6. Alterar Membro\n"
                        + "7. Excluir Membro\n"
                        + "8. Buscar Membro\n"
                        + "9. Sair";
            String opcao = JOptionPane.showInputDialog(menu);

            if (opcao == null || opcao.equals("9")) {
                break;
            }

            switch (opcao) {
                case "1":
                    adicionarEquipe();
                    break;
                case "2":
                    alterarEquipe();
                    break;
                case "3":
                    excluirEquipe();
                    break;
                case "4":
                    buscarEquipe();
                    break;
                case "5":
                    adicionarMembro();
                    break;
                case "6":
                    alterarMembro();
                    break;
                case "7":
                    excluirMembro();
                    break;
                case "8":
                    buscarMembro();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida.");
            }
        }
    }

    private static void adicionarEquipe() {
        String nome = JOptionPane.showInputDialog("Digite o nome da equipe:");
        String descricao = JOptionPane.showInputDialog("Digite a descrição da equipe:");
        Equipe equipe = new Equipe(0, nome, descricao);
        if (EquipeController.cadastrar(equipe)) {
            JOptionPane.showMessageDialog(null, "Equipe adicionada com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao adicionar equipe.");
        }
    }

    private static void alterarEquipe() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID da equipe a ser alterada:"));
        String nome = JOptionPane.showInputDialog("Digite o novo nome da equipe:");
        String descricao = JOptionPane.showInputDialog("Digite a nova descrição da equipe:");
        Equipe equipe = new Equipe(id, nome, descricao);
        if (EquipeController.alterar(equipe)) {
            JOptionPane.showMessageDialog(null, "Equipe alterada com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao alterar equipe.");
        }
    }

    private static void excluirEquipe() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID da equipe a ser excluída:"));
        Equipe equipe = new Equipe(id, null, null);
        if (EquipeController.excluir(equipe)) {
            JOptionPane.showMessageDialog(null, "Equipe excluída com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao excluir equipe.");
        }
    }

    private static void buscarEquipe() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID da equipe a ser buscada:"));
        List<Equipe> equipes = EquipeController.buscar(id);
        if (equipes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Equipe não encontrada.");
        } else {
            StringBuilder resultado = new StringBuilder("Equipes encontradas:\n");
            for (Equipe e : equipes) {
                resultado.append("ID: ").append(e.getId()).append(", Nome: ").append(e.getNome()).append(", Descrição: ").append(e.getDescricao()).append("\n");
            }
            JOptionPane.showMessageDialog(null, resultado.toString());
        }
    }

    private static void adicionarMembro() {
        String nome = JOptionPane.showInputDialog("Digite o nome do membro:");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade do membro:"));
        String funcao = JOptionPane.showInputDialog("Digite a função do membro:");
        int codEquipe = Integer.parseInt(JOptionPane.showInputDialog("Digite o código da equipe do membro:"));
        Membro membro = new Membro(0, nome, idade, funcao, codEquipe);
        if (MembroController.cadastrar(membro)) {
            JOptionPane.showMessageDialog(null, "Membro adicionado com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao adicionar membro.");
        }
    }

    private static void alterarMembro() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do membro a ser alterado:"));
        String nome = JOptionPane.showInputDialog("Digite o novo nome do membro:");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a nova idade do membro:"));
        String funcao = JOptionPane.showInputDialog("Digite a nova função do membro:");
        int codEquipe = Integer.parseInt(JOptionPane.showInputDialog("Digite o novo código da equipe do membro:"));
        Membro membro = new Membro(id, nome, idade, funcao, codEquipe);
        if (MembroController.alterar(membro)) {
            JOptionPane.showMessageDialog(null, "Membro alterado com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao alterar membro.");
        }
    }

    private static void excluirMembro() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do membro a ser excluído:"));
        Membro membro = new Membro(id, null, 0, null, 0);
        if (MembroController.excluir(membro)) {
            JOptionPane.showMessageDialog(null, "Membro excluído com sucesso.");
        } else {
            JOptionPane.showMessageDialog(null, "Erro ao excluir membro.");
        }
    }

    private static void buscarMembro() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do membro a ser buscado:"));
        List<Membro> membros = MembroController.buscar(id);
        if (membros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Membro não encontrado.");
        } else {
            StringBuilder resultado = new StringBuilder("Membros encontrados:\n");
            for (Membro m : membros) {
                resultado.append("ID: ").append(m.getId()).append(", Nome: ").append(m.getNome()).append(", Idade: ").append(m.getIdade()).append(", Função: ").append(m.getFuncao()).append(", Código da Equipe: ").append(m.getCodEquipe()).append("\n");
            }
            JOptionPane.showMessageDialog(null, resultado.toString());
        }
    }
}
